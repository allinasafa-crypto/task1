import pyjokes

print(pyjokes.get_joke())

import pyjokes

# print("Print Jokes....")
joke = pyjokes.get_joke()
print(joke)

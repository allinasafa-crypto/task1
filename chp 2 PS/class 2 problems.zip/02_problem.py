a = 34

b = 5

print("Remainder whhen a is divided by b is ", a % b)
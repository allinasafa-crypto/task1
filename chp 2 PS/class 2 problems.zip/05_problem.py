a = int(input("Enter number 1: "))
b = int(input("Enter number 2: "))

print("The averagge of two these number is ", (a+b)/2)
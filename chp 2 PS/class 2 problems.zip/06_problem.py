a = int(input("Enter your number: "))

print("Thhe square of the number is", a**2)
print("Thhe square of the number is", a*2)
# print("The square of the number is", a^2) #Incorrect for finding square of a number in Python
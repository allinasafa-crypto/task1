a = 1 # a is an integer

b = 5.22 # b is a floating point

c = "Harry" # c is a string

d = False # d is a boolean variable

e = None # e is a none type variable
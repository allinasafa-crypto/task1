a = 23

aaa = 436

harry = 34

sameer =45

_sameer = 45

# @sameer =45 invaalid due to @ symbol
# s@ameer =45 invaalid due to @ symbol

s_ameer = 45
#Arithmetic Operators
a=34
b=4
c=a+b
print(c)

#Assignment Operators
a = 4-2 #Assiggn 4-2 in a
print(a)

b = 6
# # b += 3 #Increment the value of b by 3 and then assign it to 
# b -= 3 #Decrement the value of b by 3 and then assign it to 
# b *= 3 #Multiply the value of b by 3 and then assign it to 
# b /= 3 #Divide the value of b by 3 and then assign it to 
print(b)

#Comparison Operator
d=5<4
print(d)
d=5>4
print(d)
d=5>5
print(d)
d=5>=4
print(d)
d=5!=7
print(d)

#Logical Operator
e = True or False
print(e)

#Truth Table of 'or'
print("True or False is ", True or False)
print("True or True is ", True or True)
print("False or True is ",False or True)
print("False or False is ", False or False)

#Truth Table of 'aand'
print("True and False is ", True and False)
print("True and True is ", True and True)
print("False and True is ",False and True)
print("False and False is ", False and False)

print(not(False))
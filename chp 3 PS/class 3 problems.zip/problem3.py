name = "Harry is a good  boy and "

print(name.find("  "))
print(name.find("goo"))
print(name.find(""))
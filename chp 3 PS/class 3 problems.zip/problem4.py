name = "Harry is a good  boy and "

print(name.replace("  "," "))
print(name) #str are immutable which means it can't change by running function on them
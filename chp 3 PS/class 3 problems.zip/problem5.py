letter = "Dear Harry,\n\t This python course is nice.\n Thanks!" 

print(letter)
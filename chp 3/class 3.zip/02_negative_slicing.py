name = "Harry"

print(name[0:3])

print(name[-4:-1])

print(name[1:4])

print(name[ :4]) #same as print (name[0:4])

print(name[1: ]) #same as print (name[1:5])

print(name[1:5])

#for length
nameshort = len(name)
print(nameshort)
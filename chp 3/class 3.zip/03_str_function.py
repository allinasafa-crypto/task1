name = "Harry"

print(len(name))
print(name.endswith("rry"))
print(name.endswith("rrya"))
print(name.startswith("Ha"))
print(name.startswith("ha"))

print(name.capitalize())


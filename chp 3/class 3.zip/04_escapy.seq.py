a = "Harry is a good boy\nnot a bad \t  \"boy\""
a = "Harry is a good boy\nnot a bad \t  \'boy\'"
a = 'Harry is a good boy\nnot a bad \t  \'boy\''
a = 'Harry is a good boy\nnot a bad \t  \"boy\"'

print(a)
import pyttsx3
engine = pyttsx3.init()
engine.say("I will say this text ")
engine.runAndWait()